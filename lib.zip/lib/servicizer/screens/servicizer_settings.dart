import 'package:drive_assist/user/screens/auth/user_login_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../../common widgets/custom_appBar.dart';
import '../../../common widgets/custom_settings_listTile.dart';
import '../../../constants/sizes.dart';
import '../../../constants/text_strings.dart';

class ServicizerSettingsScreen extends StatefulWidget {
  @override
  State<ServicizerSettingsScreen> createState() =>
      _ServicizerSettingsScreenState();
}

class _ServicizerSettingsScreenState extends State<ServicizerSettingsScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: apkSettingsAppBarTitle,
        onLeadingPressed: () {},
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(22.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(height: apkDefaultSize + 15),
              CustomSettingsListTile(
                leadingIcon: Icons.language_outlined,
                trailingIcon: Icons.navigate_next_rounded,
                title: apkSettingsTileTitleOne,
                onTap: () {},
                tileColor: Colors.white,
                textColor: const Color.fromARGB(255, 19, 53, 123),
                iconColor: const Color.fromARGB(255, 19, 53, 123),
                borderRadius: 10.0,
              ),
              const SizedBox(height: apkDefaultSize - 20),
              CustomSettingsListTile(
                leadingIcon: Icons.logout_rounded,
                trailingIcon: Icons.navigate_next_rounded,
                title: apkSettingsTileTitleTwo,
                onTap: () async {
                  try {
                    await _auth.signOut().then(
                          (value) => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => UserLoginScreen()),
                          ),
                        );
                  } catch (e) {
                    print(e);
                  }
                },
                tileColor: Colors.white,
                textColor: const Color.fromARGB(255, 19, 53, 123),
                iconColor: const Color.fromARGB(255, 19, 53, 123),
                borderRadius: 10.0,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
