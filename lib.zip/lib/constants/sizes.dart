const apkDefaultSize = 30.0;
