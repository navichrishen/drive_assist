const String apkLogo = "assets/logo/apk_logo.png";

const String googleLogo = "assets/logo/google_logo.png";

const String scanDialogCover = "assets/images/scanDialog.jpg";

const String servicizerLogo = "assets/logo/Servicizer.png";
