import 'package:flutter/material.dart';

import '../../../common widgets/custom_appBar.dart';
import '../../../common widgets/custom_text_field.dart';
import '../../../constants/sizes.dart';
import '../../../constants/text_strings.dart';

class UserProfileScreen extends StatefulWidget {
  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        title: apkUserProfileAppBarTitle,
        onLeadingPressed: () {},
      ),
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Column(
                        children: [
                          //codings for profile avatar
                          Center(
                            child: Stack(
                              alignment: Alignment
                                  .bottomRight, // Adjust alignment as needed
                              children: [
                                CircleAvatar(
                                  radius: 70,
                                  backgroundImage: AssetImage(
                                      'assets/images/profileAvatar.png'),
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    shape: BoxShape.circle,
                                  ),
                                  child: IconButton(
                                    icon: Icon(
                                      Icons.edit,
                                      color: Colors.blue,
                                    ),
                                    onPressed: () {
                                      // Handle edit button press
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: apkDefaultSize - 20),
                          CustomTextField(
                            labelText: apkFullNameTxt,
                            hintText: apkFullNameHintTxt,
                            prefixIcon: Icons.person_outline_outlined,
                          ),
                          const SizedBox(height: apkDefaultSize - 20),
                          CustomTextField(
                            labelText: apkEmailTxt,
                            hintText: apkEmailHintTxt,
                            prefixIcon: Icons.email_outlined,
                          ),
                          const SizedBox(height: apkDefaultSize - 20),
                          CustomTextField(
                            labelText: apkContactNumTxt,
                            hintText: apkContactNumHintTxt,
                            prefixIcon: Icons.phone_enabled_outlined,
                          ),
                          const SizedBox(height: apkDefaultSize - 20),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40),
                      child: Container(
                        padding: EdgeInsets.only(top: 3, left: 3),
                        child: MaterialButton(
                          minWidth: double.infinity,
                          height: 60,
                          onPressed: () {},
                          color: const Color.fromARGB(255, 0, 29, 61238),
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Text(
                            apkUpdateTxt,
                            style: TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
